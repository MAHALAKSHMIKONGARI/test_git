module.exports = {
    mongoURI: "mongodb+srv://isaadmin:isa@nwmissouri@isa-nwmsu-nppp3.mongodb.net/ISA-NWMSU?retryWrites=true&w=majority",
    secretOrKey: "secret"
  };